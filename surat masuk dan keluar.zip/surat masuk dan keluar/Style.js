<script>
    document.addEventListener("DOMContentLoaded", function () {
        // **Navigasi Tab**
        const tabButtons = document.querySelectorAll(".tab-button");
        const tabContents = document.querySelectorAll(".tab-content");

        tabButtons.forEach(button => {
            button.addEventListener("click", function () {
                // Remove active class
                tabButtons.forEach(btn => btn.classList.remove("active"));
                tabContents.forEach(content => content.style.display = "none");

                // Add active class and show content
                this.classList.add("active");
                document.getElementById(this.dataset.tab).style.display = "block";
            });
        });

        // **Menampilkan Modal Form Surat Masuk**
        const modalMasuk = document.getElementById("modal-surat-masuk");
        const btnAddMasuk = document.getElementById("add-surat-masuk");
        const btnCloseMasuk = document.getElementById("close-surat-masuk");

        btnAddMasuk.addEventListener("click", function () {
            modalMasuk.style.display = "block";
        });

        btnCloseMasuk.addEventListener("click", function () {
            modalMasuk.style.display = "none";
        });

        window.addEventListener("click", function (event) {
            if (event.target === modalMasuk) {
                modalMasuk.style.display = "none";
            }
        });

        // **Menampilkan Modal Form Surat Keluar**
        const modalKeluar = document.getElementById("modal-surat-keluar");
        const btnAddKeluar = document.getElementById("add-surat-keluar");
        const btnCloseKeluar = document.getElementById("close-surat-keluar");

        btnAddKeluar.addEventListener("click", function () {
            modalKeluar.style.display = "block";
        });

        btnCloseKeluar.addEventListener("click", function () {
            modalKeluar.style.display = "none";
        });

        window.addEventListener("click", function (event) {
            if (event.target === modalKeluar) {
                modalKeluar.style.display = "none";
            }
        });

        // **Menambahkan Data Surat Masuk**
        const formSuratMasuk = document.getElementById("form-surat-masuk");
        const tableMasukBody = document.getElementById("surat-masuk-body");

        formSuratMasuk.addEventListener("submit", function (event) {
            event.preventDefault(); // Mencegah refresh halaman

            // Ambil data dari form
            const kodeSurat = document.getElementById("kode-surat-masuk").value;
            const asalSurat = document.getElementById("asal-surat").value;
            const perihal = document.getElementById("perihal-masuk").value;
            const nomorSurat = document.getElementById("nomor-surat-masuk").value;

            // Tambahkan ke tabel
            const row = `<tr>
                <td>${tableMasukBody.children.length + 1}</td>
                <td>${kodeSurat}</td>
                <td>${new Date().toLocaleDateString()}</td>
                <td>${asalSurat}</td>
                <td>${perihal}</td>
                <td>${nomorSurat}</td>
                <td class="no-print">
                    <button class="edit-btn action-btn">✏️</button>
                    <button class="delete-btn action-btn">🗑️</button>
                </td>
            </tr>`;

            tableMasukBody.innerHTML += row;
            modalMasuk.style.display = "none"; // Tutup modal
            formSuratMasuk.reset(); // Reset form
        });

        // **Pencarian Surat Masuk**
        document.getElementById("search-btn-masuk").addEventListener("click", function () {
            const searchValue = document.getElementById("search-masuk").value.toLowerCase();
            const rows = tableMasukBody.querySelectorAll("tr");

            rows.forEach(row => {
                row.style.display = row.innerText.toLowerCase().includes(searchValue) ? "" : "none";
            });
        });

        // **Cetak Surat Masuk**
        document.getElementById("print-surat-masuk").addEventListener("click", function () {
            window.print();
        });

        // **Export Data Surat Masuk ke Excel**
        document.getElementById("export-surat-masuk").addEventListener("click", function () {
            let table = document.getElementById("table-surat-masuk");
            let rows = Array.from(table.rows)
                .map(row => Array.from(row.cells).map(cell => cell.innerText).join(","))
                .join("\n");

            let csvContent = "data:text/csv;charset=utf-8," + rows;
            let encodedUri = encodeURI(csvContent);
            let link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "data_surat_masuk.csv");
            document.body.appendChild(link);
            link.click();
        });
    });
</script>